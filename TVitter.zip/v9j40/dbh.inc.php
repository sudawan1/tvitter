<?php

$conn = mysqli_connect('dalek.scam.keele.ac.uk', 'v9j40','v9j40','v9j40');

if (!$conn) {
    die("Connection failed: ".mysqli_connect_error());
}