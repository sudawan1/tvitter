<!DOCTYPE html>
<html>
<head> 
<meta charset="UTF-8">
<title>TVitter</title>
<link rel="stylesheet" href="style.css" >
<link rel="stylesheet" type="text/css" href="styleheader.css" />
<link href='//fonts.googleapis.com/css?family=Noto Serif' rel='stylesheet'>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>

<script>
	function strengthChecker() { 
			var passwordInput=document.getElementById("passwordboxlogin"); 
			var password=passwordInput.value; 
			var specialcharacters="!£$%^&*"; 
			var passwordScore=0; 
			
			for (var i=0; i<password.length; i++) {
				if(specialcharacters.indexOf(password.charAt(i))> -1) {
					passwordScore+=1;
				}
			}
			if (/[a-z]/.test(password)) { 
				passwordScore+=1;
			}
			if (/[A-Z]/.test(password)) { 
				passwordScore+=1;
			}
			if (password.length>=5) {
				passwordScore+=1;
			}
			
			var strength="";
			var bgColor="";
			
			if (passwordScore>=4) { 
				strength="Strong";
				bgColor="green"
			}
			else if (passwordScore>=2) { 
				strength="Medium";
				bgColor="purple";
			}
			else { 
				strength="Weak";
				bgColor="red";
			}
			
			document.getElementById("label").innerHTML=strength;  
			passwordboxlogin.style.color=bgColor; 
			
		}
	</script>
</head>
<body>

<?php
    include 'header.php';
?>

<div class="loginbox">
<form id="detailsForm" class="boxlogin" action="login.php" method="get">
     <input type="text" name="uid" class="boxlogin" placeholder="Username" required pattern='.{3,}'><br>
     <input type="password" name="pwd" class="boxlogin" placeholder="Password" required pattern='.{3,}'><br> 
    <button type="submit" class="boxlogin">LOGIN</button>
    <br>
<?php
    if (isset($_SESSION['id'])) {
        echo $_SESSION['id'];
    } else {
        echo "You are not logged in!";}
?>
</form>

<br><br><br>


<form id="detailsForm" class="boxlogin" action="signup.php" method="get">
    <input type="text" name="first" class="boxlogin" placeholder="Firstname" required pattern='.{3,}'><br>
    <input type="text" name="last" class="boxlogin" placeholder="Lastname" required pattern='.{2,}'><br>
    <input type="text" name="uid" class="boxlogin" placeholder="Username" required pattern='.{2,}'><br>
    <input type="password" name="pwd" class="boxlogin" id='passwordboxlogin' placeholder="Password" required pattern='.{2,}' onkeyup="strengthChecker()"><br> 
	<label id='label'></label>
    <input type="email" name="email" class="boxlogin" placeholder="Email" required pattern='.{2,}'><br>
    <br><br>
    <button type="submit" class="boxlogin">SIGN UP</button>
</form>
<?php
if (isset($_SESSION['id'])) {
?>
<form id="detailsForm" action="logout.php">

    <form id="logout" action=logout.php>
    <button>LOG OUT</button>
</form>
<?php
}
?>
</div>
</body>
</html>