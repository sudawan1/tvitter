<?php include ("header.php"); ?>
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" type="text/css" href="styleheader.css" />

<?php
if(isset($_SESSION['id'])){
//var_dump($_SESSION['id']);
echo "
<form method='POST' action='biodone.php'>
<form action='done.php' method='get'>
<input type='hidden' name='uid' value='".$_SESSION['id']."'>
<textarea name='bio' required>
</textarea>
<button id=submitprofile type='submit' name='biodone'>Make Bio</button>
</form>";
}
else {
echo "Log in to edit bio";
}
