<html>
<head>
<link rel="stylesheet" type="text/css" href="styleheader.css" />
<link rel="stylesheet" type="text/css" href="style.css" />
<?php include ("header.php"); ?>
<?php include ("dbh.inc.php"); ?>
<?php include ('comments.inc.php'); ?>
</head>


<body>
<?php
    $tag=$_GET['tag'];
    $sql= "SELECT * FROM comments WHERE tag1='$tag' ORDER BY date DESC";
    $result = mysqli_query($conn,$sql); //run quiry we have
    while ($row = $result->fetch_assoc()) { //spit out comments
        $id = $row['uid']; //get id from user inside the post
        $sql2 = "SELECT * FROM user WHERE id='$id'"; //getting the username to show when comment, where everything is 2
        $result2 = mysqli_query($conn,$sql2 );
        if ($row2 = $result2->fetch_assoc()) {
            echo "<div class='comment-box'><p>"; //spit the post so its showing the author of the post   
            echo "<a href='seeanyprofile.php?username=".$row2['uid']."'>".$row2['uid']."<br>"."</a>";//$row2['uid']."<br>";
            echo "<b>"."<a href='linkfortag.php?tag=".$row['tag1']."'>"."</b>"."<b>"."Tag: "."</b>".$row['tag1']."<br>"."</a>";
            echo "<b>"."TV episode name: "."</b>".$row['TVepisodeName']."<br>";
            echo "<b>"."TV programme name: "."</b>".$row['TVProgrammeName']."<br>";
            echo $row['date']."<br>";
            echo $row['message'];
            echo "</p>";
            if (isset($_SESSION['id'])) {
                if ($_SESSION['id'] == $row2['id']) {
                    echo "</p>
                        <form class='delete-form' method='POST' action='".deleteComments($conn)."'>
                        <input type='hidden' name='cid' value='".$row['cid']."'>
                        <button type='submit'name= 'commentDelete'>Delete</button>
                    </form>
            
                    <form class='edit-form' method='POST' action='toeditmessage.php'>
                        <input type='hidden' name='cid' value='".$row['cid']."'>
                        <input type='hidden' name='uid' value='".$row['uid']."'>
                        <input type='hidden' name='date' value='".$row['date']."'>
                        <input type='hidden' name='message' value='".$row['message']."'>
                        <button>Edit</button>
                    </form>";
                } else {
                    echo "</p>
                        <form class='edit-form' method='POST' action='".deleteComments($conn)."'>
                        <input type='hidden' name='cid' value='".$row['cid']."'>
                        <button type='submit'name= 'commentDelete'>Reply</button>
                    </form>"  ;
                }
            } else {
                echo "<p class='commentmessage'>You need to be logged in TVitter to reply!</p>";
            } 
            echo "</div>";
        } 
    }
?>

</body>
</html>