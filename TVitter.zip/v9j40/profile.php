<?php include ("header.php"); ?>
<?php include ("dbh.inc.php"); ?>
<?php include ('comments.inc.php'); ?>
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" type="text/css" href="styleheader.css" />

<form action=makeprofile.php>
    <button id=makeprofilebutton> Write and edit bio</button>
</form>

</div>

<div class='bio'>
<?php
$id=$_SESSION['id'];
$sql = "SELECT bio FROM user WHERE id=$id"; //going to database get comment by most recent date first
    $result = mysqli_query($conn,$sql); //run quiry we have
    while ($row = $result->fetch_assoc()) { //spit out comments
    echo "<i>"."My Bio: "."</i>".$row['bio'];

    }
    
?>

<br><br><br><br>

</div>
<div class='email'>
<?php
$id=$_SESSION['id'];
$sql = "SELECT email FROM user WHERE id=$id"; //going to database get comment by most recent date first
    $result = mysqli_query($conn,$sql); //run quiry we have
    $row = mysqli_fetch_assoc($result);  //spit out comments
    echo "<i>"."My Email: "."</i>".$row['email'];
?>
</div>

<br><br><br><br>

<div>
<?php
    $id=$_SESSION['id'];
    //echo"$id";
    //$sql= "SELECT message FROM comments WHERE uid=$id";
    //$result=mysqli_query($conn, $sql);
    //$row=mysqli_fetch_assoc($result);
    //echo $row['message'];
    getProfileComments($conn);
?>

