<?php

//setting comment section to the databse and to make sure it's not over 140 character
function setComments($conn) {
    if (isset($_POST['commentSubmit'])) {
        if (strlen ($_POST['message'])>140) {
            echo "Post is more than 140 character";
        }
         else{
           
        $uid = mysqli_real_escape_string($conn, $_POST['uid']); //sql inject protect a website
        $date = mysqli_real_escape_string($conn, $_POST['date']); 
        $message = mysqli_real_escape_string($conn, $_POST['message']); 
        $tvepisode = $_POST['TVepisodeName'];
        $tvprogramme = $_POST['TVProgrammeName'];
        $tag1 = $_POST['tag1'];
        
        $sql = "INSERT INTO comments (uid, date, message, TVepisodeName, TVProgrammeName, tag1) VALUES ('$uid','$date','$message', '$tvepisode', '$tvprogramme', '$tag1')";
        $result = mysqli_query($conn,$sql);
        //exit();
 
    }
}
}  


//to get all comment from database to show
function getComments($conn) {
    $sql = "SELECT * FROM comments ORDER BY date DESC"; //going to database get comment by most recent date first
    $result = mysqli_query($conn,$sql); //run quiry we have
    while ($row = $result->fetch_assoc()) { //spit out comments
        $id = $row['uid']; //get id from user inside the post
        $sql2 = "SELECT * FROM user WHERE id='$id'"; //getting the username to show when comment, where everything is 2
        $result2 = mysqli_query($conn,$sql2 );
        if ($row2 = $result2->fetch_assoc()) {
            echo "<div class='comment-box'><p>"; //spit the post so its showing the author of the post   
            echo "<a href='seeanyprofile.php?username=".$row2['uid']."'>".$row2['uid']."<br>"."</a>";//$row2['uid']."<br>";
            echo "<b>"."<a href='linkfortag.php?tag=". $row['tag1']."'>"."</b>"."<b>"."Tag: "."</b>".$row['tag1']."<br>"."</a>";
            echo "<b>"."TV episode name: "."</b>".$row['TVepisodeName']."<br>";
            echo "<b>"."TV programme name: "."</b>".$row['TVProgrammeName']."<br>";
            echo $row['date']."<br>";
            echo $row['message'];
            echo "</p>";
            if (isset($_SESSION['id'])) {
                if ($_SESSION['id'] == $row2['id']) {
                    echo "</p>
                        <form class='delete-form' method='POST' action='".deleteComments($conn)."'>
                        <input type='hidden' name='cid' value='".$row['cid']."'>
                        <button type='submit'name= 'commentDelete'>Delete</button>
                    </form>
            
                    <form class='edit-form' method='POST' action='toeditmessage.php'>
                        <input type='hidden' name='cid' value='".$row['cid']."'>
                        <input type='hidden' name='uid' value='".$row['uid']."'>
                        <input type='hidden' name='date' value='".$row['date']."'>
                        <input type='hidden' name='message' value='".$row['message']."'>
                        <button>Edit</button>
                    </form>";
                } else {
                    echo "</p>
                        <form class='edit-form' method='POST' action='".deleteComments($conn)."'>
                        <input type='hidden' name='cid' value='".$row['cid']."'>
                        <button type='submit'name= 'commentDelete'>Reply</button>
                    </form>"  ;
                }
            } else {
                echo "<p class='commentmessage'>You need to be logged in TVitter to comment!</p>";
            } 
            echo "</div>";
        } 
    }
}

function editComments($conn) {
    if (isset($_POST['commentSubmit'])) {
        if (strlen ($_POST['message'])>140) {
            echo "Post is more than 140 character";
        }
         else{
        $cid = $_POST['cid'];  
        $uid = $_POST['uid'];
        $date = $_POST['date'];
        $message = $_POST['message'];

        $sql = "UPDATE comments SET message='$message' WHERE cid='$cid'";
        $result = mysqli_query($conn,$sql);   
        //header("Location: commentsection.php");
    }
}
}

function deleteComments($conn) {
if (isset($_POST['commentDelete'])) {
    $cid = $_POST['cid'];  

        $sql = "DELETE FROM comments WHERE cid='$cid'";
        $result = mysqli_query($conn,$sql);   
    }
}

function getLogin($conn, $uid, $pwd) {
//    if (isset($_POST['loginSubmit'])) {
//        $uid = $_POST['uid'];
//        $pwd = $_POST['pwd'];
    
        $statement = $conn->prepare("SELECT * FROM user WHERE uid=? AND pwd=?"); //prepare statement to prevent sql injection
        $statement->bind_param("ss", $username, $password);
        
        $username = $uid;
        $password = $pwd;
        $statement->execute();
        
        $result = $statement->get_result();
        
        $rowNum = $result->num_rows;

        if ($rowNum > 0) {
            if ($row = $result->fetch_assoc()) {
                $_SESSION['id'] = $row['id'];
                $_SESSION['uid'] = $row['uid'];
                //header("Location: ?loginsuccess");
                return True;
            }  
        } else {
                //header("Location: commentsection.php?loginfailed");
          //      exit();
                return False;
        }
    //}
}

function userLogout() {
      //if (isset($_POST['logoutSubmit'])) {
          session_destroy();
          return True;
          //header("Location: commentsection.php");
          //exit();
      //}
}

function getProfileComments($conn) {
    if (isset($_SESSION['id'])) {
    $uid=$_SESSION['id'];
    $sql = "SELECT * FROM comments WHERE uid='$uid' ORDER BY date DESC"; //going to database get comment by most recent date first
    $result = mysqli_query($conn,$sql); //run quiry we have
    while ($row = $result->fetch_assoc()) { //spit out comments
        $id = $row['uid']; //get id from user inside the post
        $sql2 = "SELECT * FROM user WHERE id='$id'"; //getting the username to show when comment, where everything is 2
        $result2 = mysqli_query($conn,$sql2 );
        if ($row2 = $result2->fetch_assoc()) {
            echo "<div class='comment-box'><p>"; //spit the post so its showing the author of the post   
            echo $row2['uid']."<br>";
            echo "<b>"."<a href='linkfortag.php?tag=".$row['tag1']."'>"."</b>"."<b>"."Tag: "."</b>".$row['tag1']."<br>"."</a>";
            echo "<b>"."TV episode name: "."</b>".$row['TVepisodeName']."<br>";
            echo "<b>"."TV programme name: "."</b>".$row['TVProgrammeName']."<br>";
            echo $row['date']."<br>";
            echo $row['message'];
          
            echo "</p>";
            if (isset($_SESSION['id'])) {
                if ($_SESSION['id'] == $row2['id']) {
                    echo "</p>
                        <form class='delete-form' method='POST' action='".deleteComments($conn)."'>
                        <input type='hidden' name='cid' value='".$row['cid']."'>
                        <button type='submit'name= 'commentDelete'>Delete</button>
                    </form>
            
                    <form class='edit-form' method='POST' action='toeditmessage.php'>
                        <input type='hidden' name='cid' value='".$row['cid']."'>
                        <input type='hidden' name='uid' value='".$row['uid']."'>
                        <input type='hidden' name='date' value='".$row['date']."'>
                        <input type='hidden' name='message' value='".$row['message']."'>
                        <button>Edit</button>
                    </form>";
                } else {
                    echo "</p>
                        <form class='edit-form' method='POST' action='".deleteComments($conn)."'>
                        <input type='hidden' name='cid' value='".$row['cid']."'>
                        <button type='submit'name= 'commentDelete'>Reply</button>
                    </form>"  ;
                }
            } else {
                echo "<p class='commentmessage'>You need to be logged in TVitter to comment!</p>";
            } 
            echo "</div>";
        } 
    }
}
}

