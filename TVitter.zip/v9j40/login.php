<?php
session_start();
include 'dbh.inc.php'; 

$uid = $_GET['uid'];
$pwd = $_GET['pwd'];

$sql = "SELECT * FROM user WHERE uid= '$uid' AND pwd='$pwd'";
$result = mysqli_query($conn,$sql);

if (!$row = mysqli_fetch_assoc($result)) {
    echo "Your username or password is incorrect!
    please try again";
    echo '<a href="logintest.php">Click here</a>';
    //header("Location: logintest.php");
} 
else {    
    $_SESSION['id'] = $row['id'];
    header("Location: commentsection.php");
}

