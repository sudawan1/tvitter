<?php include ("header.php"); ?>
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" type="text/css" href="styleheader.css" />


<?php
    //var_dump($_POST);
    $bio= $_POST['bio'];
    $sql= "UPDATE user SET bio = '$bio' WHERE id = ".$_SESSION['id'];
    $result = mysqli_query($conn, $sql);
    if ($result) {
        $local= 'profile.php?confirm=TRUE';
    } else {
        $local= 'profile.php?confirm='.$id;
    }
    
    '<a href="profile.php">Click here</a>';
    //header("Location: $local");
   
    
?>
<p class="comment"> please click <b>Profile</b> to go back to <b>Profile</b><w/p>