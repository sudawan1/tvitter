-- phpMyAdmin SQL Dump
-- version 4.0.3
-- http://www.phpmyadmin.net
--
-- Host: dalek.scam.keele.ac.uk
-- Generation Time: May 04, 2017 at 03:11 PM
-- Server version: 5.1.58
-- PHP Version: 5.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `v9j40`
--
CREATE DATABASE IF NOT EXISTS `v9j40` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `v9j40`;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(128) NOT NULL,
  `date` datetime NOT NULL,
  `message` varchar(140) NOT NULL,
  `tag1` varchar(200) NOT NULL,
  `TVepisodeName` varchar(300) NOT NULL,
  `TVProgrammeName` varchar(300) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=83 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`cid`, `uid`, `date`, `message`, `tag1`, `TVepisodeName`, `TVProgrammeName`) VALUES
(45, 'Anonymous', '2017-03-09 16:15:40', 'hsdfsudbfoisb\r\n\r\n\r\nkjfgbkfbge', '', '', ''),
(46, 'Anonymous', '2017-03-09 16:15:40', 'hsdfsudbfoisb\r\n\r\n\r\nkjfgbkfbge', '', '', ''),
(47, 'Anonymous', '2017-03-09 16:15:40', 'hsdfsudbfoisb\r\n\r\n\r\nkjfgbkfbge', '', '', ''),
(48, 'Anonymous', '2017-03-09 16:15:40', 'hsdfsudbfoisb\r\n\r\n\r\nkjfgbkfbge', '', '', ''),
(49, 'Anonymous', '2017-03-09 16:15:40', 'hsdfsudbfoisb\r\n\r\n\r\nkjfgbkfbge', '', '', ''),
(55, 'Anonymous', '2017-03-10 15:35:25', 'hi', '', '', ''),
(56, 'Anonymous', '2017-03-10 15:35:25', 'hi', '', '', ''),
(57, 'Anonymous', '2017-03-10 15:35:25', 'hi', '', '', ''),
(58, 'Anonymous', '2017-03-10 15:35:25', 'hi', '', '', ''),
(59, 'Anonymous', '2017-03-10 15:35:25', 'hi', '', '', ''),
(63, '2', '2017-03-14 17:46:49', 'hi this is a test', '', '', ''),
(64, '2', '2017-03-16 14:25:55', 'TVitter is awesome', '', '', ''),
(65, '2', '2017-03-16 14:25:55', 'TVitter is awesome', '', '', ''),
(66, '2', '2017-03-16 14:25:55', 'TVitter is awesome', '', '', ''),
(67, '1', '2017-04-18 14:26:51', 'TEST', '', 'test', ''),
(68, '1', '2017-04-18 14:26:51', 'TEST', '', 'test', 'test'),
(69, '1', '2017-04-18 14:26:51', 'TEST', '', 'test', 'test'),
(70, '1', '2017-04-18 14:26:51', 'TEST', '', 'test', 'test'),
(71, '1', '2017-04-18 14:26:51', 'TEST', '', 'test', 'test'),
(72, '1', '2017-04-18 14:26:51', 'TEST', '', 'test', 'test'),
(73, '47', '2017-04-20 14:25:06', 'bb', '', '', ''),
(79, '3', '2017-04-20 15:26:02', 'Can''t stop binge watching this OMG!', '', 'Die', 'How to get away with murder'),
(80, '3', '2017-04-21 11:58:11', '', '', '', ''),
(82, '3', '2017-04-25 14:22:02', '', 'confuse', 'am i lost', 'lost');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `name` varchar(40) NOT NULL,
  `phone` char(5) NOT NULL,
  `email` char(5) NOT NULL,
  `position` char(1) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`name`, `phone`, `email`, `position`) VALUES
('BRERETON,Pearl', '33079', 'csa14', 'P'),
('COLLINS,David', '33251', 'csa27', 'L'),
('DAY,Charles', '33411', 'csa35', 'L'),
('FLETCHER,Peter', '33260', 'maa03', 'L'),
('HAWKSLEY,Chris', '33412', 'csa04', 'S'),
('KITCHENHAM,Barbara', '33413', 'csa17', 'P'),
('LINKMAN,Steve', '33413', 'csa18', 'S'),
('NELIGWA,Thomas', '33476', 'csd09', 'L'),
('RUGG,Gordon', '33410', 'csa41', 'S'),
('THOMASON,Stuart', '34083', 'csa29', 'L'),
('', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(128) NOT NULL,
  `pwd` varchar(128) NOT NULL,
  `bio` varchar(5000) NOT NULL,
  `first` varchar(128) NOT NULL,
  `last` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `uid`, `pwd`, `bio`, `first`, `last`, `email`) VALUES
(1, 'admin', '123', '', 'Sudawan', 'Kumdee', 'email@gmail.com'),
(2, 'sudawan', '123', '', '', '', ''),
(3, 'alexauser', 'alexa', 'I love TVitter!!!', 'alexa', 'green', 'alexa@hotmail.com'),
(4, 'alexauser', '', '', 'alexa', 'green', 'alexa@hotmail.com'),
(5, 'alexauser', '', '', 'alexa', 'green', 'alexa@hotmail.com'),
(6, 'hi', '123', '', 'hiiiii', 'bye', 'hi@gmail.com'),
(7, '', '', '', '', '', ''),
(8, '', '', '', '', '', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
