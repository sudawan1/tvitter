<?php
session_start();
include 'dbh.inc.php'; 

$first = $_GET['first'];
$last = $_GET['last'];
$uid = $_GET['uid'];
$pwd = $_GET['pwd'];
$email=$_GET['email'];

//adding user data to database table in myphp
$sql = "INSERT INTO user (first,last,uid,pwd,email) 
VALUES ('$first', '$last','$uid','$pwd', '$email')";

$result = mysqli_query($conn, $sql);

   if ($result) {
   
   
   $_SESSION['id'] = mysqli_insert_id($conn);
    header("Location: commentsection.php");
    
    
    } else { 
       ?> 
        <!DOCTYPE html>
<html>
<body>
        
        
        Username already exist! please try again
        <a href="logintest.php">Click here</a>
</body>
</html>
<?php
}

//header("Location: logintest.php");

?>


