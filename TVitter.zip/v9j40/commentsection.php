<?php
    date_default_timezone_set('Europe/London');
    //session_start();
    include 'header.php';

    
    
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>TVitter</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" type="text/css" href="styleheader.css" />
<link href='//fonts.googleapis.com/css?family=Noto Serif' rel='stylesheet'>
</head>

<body>

<?php

    include 'comments.inc.php';
    //echo "<form method='POST' action='login.php'>
        //<input type='text' name='uid'>
        //<input type='password' name='pwd'>
        //<button type='submit' name='loginSubmit'>Login</button>
    //</form>";
    //echo "<form method='POST' action='login.php'>
        //<button type='submit' name='logoutSubmit'>Log out</button>
    //</form>";

    if (isset($_SESSION['id'])) {
        echo "<p class='welcome'>Welcome to Tvitter!</p>";
    } else {
        echo  "<p class='welcome'>You are NOT logged in TVitter!</p>";
    }
?>
<br>

<?php
 if (isset($_SESSION['id'])) {
        echo "<p class='welcome'>You are logged in TVitter!</p>";
        
    echo "<form method='POST' action='".setComments($conn)."'>
        <input type='hidden' name='uid' value='".$_SESSION['id']."'>
        <input type='hidden' name='date' value='".date('Y-m-d H:i:s')."'>
      
        <textarea name='message' class='message' required></textarea><br>
        <div>
        <textarea name='TVepisodeName' class='TVepisodeName' placeholder='TV Episode Name' required></textarea><br>
        <textarea name='TVProgrammeName' class='TVProgrammeName' placeholder='TV Programme Name' required></textarea><br>
        <textarea name='tag1' class='tag1' placeholder='Tag'required ></textarea><br>
        </div>
        <button type='submit' name='commentSubmit'>Comment</button>
    </form>";
    } else {
        echo  "You need to be logged in to comment on TVitter!
        <br><br>";
    }


getComments($conn);
?>



</body>

</html>