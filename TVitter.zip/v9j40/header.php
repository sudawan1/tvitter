<?php
    session_start();
    include 'dbh.inc.php';
?>

<div class="headerBox">
	<div class="title">TVitter</div>
	
</div>

<?php
if(isset($_SESSION['id'])){
	echo"
	<div id='boxlogin'>
		<form id='logout' action= logout.php>
			<button id='logout'>Log Out</button>
		</form>

	
		<form id= 'profile' action= profile.php>
			<button id= 'profile'>Profile</button>
			</form>
			
			
		<form id= 'Newsfeed' action= commentsection.php>
			<button id= 'mainpage'>Newsfeed</button>
			</form>
	</div>";
}
else {
echo"
<div id='boxnotlogin'>
   
		
		<form id='login' action= logintest.php>
			<button id='login'>Log In</button>
		</form>
	
		<form id= 'Newsfeed' action= commentsection.php>
			<button id= 'mainpage'>Newsfeed</button>
			</form>
	</div>";
}

//else {
//echo"
		//<form id= 'Newsfeed' action= commentsection.php>
			//<button id= 'mainpage'>Newsfeed</button>
			//</form>
	//</div>";
//}



?>